from . import cnhubert, whisper_enc

content_module_map = {
    'cnhubert': cnhubert,
    'whisper': whisper_enc
}